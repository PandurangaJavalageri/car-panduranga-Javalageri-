﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace car_assessment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int   count = 1, day = 2,prev=1,retail=0,rcount=1,aug15=0,oddmonth=0,curr=0,totalreatil=0,totalcorp=0;

            for(int i = 1;i<30;i++)
            {
                
                curr=(prev+2*i );
                if ((i + 1) % 5 == 0)
                {
                    Console.WriteLine(rcount);
                    retail += rcount;
                    rcount = 0;
                }
                else
                {
                    rcount += curr;
                }
                if((i+2)%15==0)
                {
                    aug15=curr;
                }
                
                prev = curr;
                count += curr;

            }
            
            oddmonth = curr + (2 * 30);
            totalreatil = retail * 6 + 3 * (curr + (2 * 30));
            totalcorp = (count - retail) * 6;
            Console.WriteLine($"no of vehicles sold in april month is {count}");
            Console.WriteLine($"no of vehicles sold in may month is {oddmonth}");
            Console.WriteLine($"no of vehicles sold in june month is {count}");
            Console.WriteLine($"no of vehicles sold in july month is {oddmonth}");
            Console.WriteLine($"no of vehicles sold in aug month is {oddmonth}");
            Console.WriteLine($"no of vehicles sold in sept month is {count}");
            Console.WriteLine($"no of vehicles sold for reatil customers:  {totalreatil}");
            Console.WriteLine($"no of vehicles sold for corporate customers:  {totalcorp}");
            Console.WriteLine($"no of vehicles sold for from aug15 to sep 15 customers:  {totalreatil}");









        }
    }
}
